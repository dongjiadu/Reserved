<? include("top.php");?><?
session_start();
if(isset($_SESSION['name'])){
$name=$_SESSION['name'];
}else{session_unregister("uid");exit("错误！用户不存在。<a href=login.php>点此重新登陆</a>");}
$sn=md5($name);
$id=$_GET['id'];
$db=sqlite_open("note/{$sn}.db");
$sql="select * from note where id='$id'";
if(!sqlite_query($db,$sql)){echo "数据库错误";}
$query=sqlite_query($db,$sql);
$res=sqlite_fetch_array($query);
$title=$res['title'];
$nr=$res['nr'];
$time=$res['time'];
$id=$res['id'];
?>
<html><title>爱笔记－删除<? echo $title;?></title>
<?php
echo $head;
if($_GET['action']=="ok")
{$sql="DELETE FROM note WHERE id = '$id'";
$a=sqlite_query($db,$sql);
if($a){echo "<font color=#FF0000>删除成功^_^</font>";}else{echo "<font color=#FF0000>删除失败T_T</font>";}}else{echo "你确定要删除笔记-“{$title}”吗？<br/>[<a href=del.php?id={$id}&action=ok>确定</a>]";}?><div class=main><a href=zone.php><font color=#FFFFFF><<返回列表</font></a></div>
<? include("foot.php");?>