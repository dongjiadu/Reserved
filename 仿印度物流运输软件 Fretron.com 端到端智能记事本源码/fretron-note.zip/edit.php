<? include("top.php");?><?
session_start();
if(isset($_SESSION['name'])){
$name=$_SESSION['name'];
}else{session_unregister("uid");exit("错误！用户不存在。<a href=login.php>点此重新登陆</a>");}
$sn=md5($name);
$id=$_GET['id'];
$db=sqlite_open("note/{$sn}.db");
$sql="select * from note where id='$id'";
if(!sqlite_query($db,$sql)){echo "数据库错误";}
$query=sqlite_query($db,$sql);
$res=sqlite_fetch_array($query);
$title=$res['title'];
$nr=$res['nr'];
$time=$res['time'];
$id=$res['id'];
?>
<html><title>爱笔记－编辑<? echo $title;?></title>
<?php
echo $head;
if($_POST['submit'])
{
$title=$_POST['title'];
$nr=$_POST['nr'];$sql="UPDATE note SET title = '$title' WHERE id = '$id'"; $a=sqlite_query($db,$sql);
$sql="UPDATE note SET nr = '$nr' WHERE id = '$id'"; $b=sqlite_query($db,$sql);
if($b && $a){echo "<font color=#FF0000>修改成功^_^</font>";}else{echo "<font color=#FF0000>修改失败T_T</font>";}}?><? if(!empty($title)&&!empty($nr)){echo '<form method="post" >
<br>笔记标题<br/><input name="title" type="text" value="'.$title.'">
<br>笔记内容<br/><input name="nr" type="text" value="'.$nr.'">
<input type="submit" name="submit" value="确认修改"></form>';}else{echo "笔记不存在哦…";}?><div class=main><a href=zone.php><font color=#FFFFFF><<返回列表</font></a></div>
<? include("foot.php");?>