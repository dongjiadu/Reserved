<html><meta http-equiv="content-type" content="text/html; charset=utf-8">
<?
if(isset($_SESSION['name'])){header("location: zone.php");}
else{header("location: login.php");}
?></html>