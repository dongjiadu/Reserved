<?
$db=sqlite_open("db/user.db");
$sql="create table user (id INTEGER PRIMARY KEY,name text,password text);";
$result=sqlite_query($db,$sql);?>