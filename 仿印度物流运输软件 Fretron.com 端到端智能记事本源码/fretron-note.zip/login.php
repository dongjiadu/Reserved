<? include("top.php");?>
<title>爱笔记-会员登陆</title><?php
if($_POST['submit'])
{
$name=$_POST['name'];
$pw=$_POST['pw'];
$db=sqlite_open("db/user.db");
$sql="select * from user where name='$name'";
$query=sqlite_query($db,$sql);
$res=sqlite_fetch_array($query); 
if($name=="" OR $pw==""){$msg="输入项不能为空！";}
elseif($res['name']<>$name){$msg="用户名不存在！";}
elseif($res['password']<>$pw){$msg="密码错误！";}
elseif($res['password']==$pw){
$uid=$res['id'];
session_start();
session_register("uid");session_register("name");
header("location: zone.php");
}else{$msg="数据库错误！";}
}
echo $head;?><form method="post" action="login.php">
<br>登陆名:<input name="name" type="text" size="4"><font color=red><? echo $msg;?></font>
<br>密码:<input name="pw" type="text" size="4"><br/><input type="submit" name="submit" value="登陆"></form><div class=main>没有帐号?<a href=reg.php>注册一个>></a></div>
<? include("foot.php");?>
