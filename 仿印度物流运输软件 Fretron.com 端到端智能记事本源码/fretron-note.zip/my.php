<? include("top.php");?>
<?
session_start();
if(isset($_SESSION['uid'])){
$uid=$_SESSION['uid'];
$db=sqlite_open("db/user.db");
$sql="select * from user where id='$uid'";
$query=sqlite_query($db,$sql);$res=sqlite_fetch_array($query);
if($res['name']==""){session_unregister("uid");exit("用户不存在！<a href=login.php>点此重新登陆</a>");}
echo $head.'<div class=tl><font color=#000000>登陆信息</font></div><hr>';
$sn=md5($res['name']);
$fs=filesize("note/{$sn}.db")/1000;
$sy=100-$fs;
$bfs=round($sy,2);
echo "用户名:{$res['name']}(ID:{$res['id']})<br/>登陆密码:{$res['password']}<div class=main><font color=#FFFFFF>数据库信息</font></div>可用数据库大小:100KB<br/>已用数据库大小:{$fs}KB<br/>剩余容量:{$sy}KB({$bfs}%)";echo "<div class=main><a href=zone.php><font color=#FFFFFF><<返回前一页</font></a></div>";}
else{header("location: login.php");}
?><? include("foot.php");?>