<? include("top.php");?>
<title>新建笔记</title><?php
session_start();
if(isset($_SESSION['uid'])){
$uid=$_SESSION['uid'];
$db=sqlite_open("db/user.db");
$sql="select * from user where id='$uid'";$query=sqlite_query($db,$sql);$res=sqlite_fetch_array($query);}else{session_unregister("uid");exit("错误！你还没有登陆。<a href=login.php>点此登陆</a>");}

if($res['name']==""){session_unregister("uid");exit("错误！用户不存在。<a href=login.php>点此重新登陆</a>");}
if($_POST['submit'])
{
$title=$_POST['title'];
$nr=$_POST['nr'];
$sn=md5($res['name']);
$db=sqlite_open("note/{$sn}.db");
if(empty($title) or empty($nr)){echo "标题和内容不能为空！";exit();}
$id=$res['id'];
date_default_timezone_set (PRC);
$now=date("Y-m-d H:i:s");
$sql="insert into note (title,nr,time) values ('$title','$nr','$now')";
$result=sqlite_query($db,$sql);
if($result){
echo "<a href=zone.php>新建成功！点此查看。</a>";
exit();}else{echo "数据库错误！";exit();}
}?><? echo $head;?><div class=tl>新建笔记</div><form method="post" action="new.php">
<br>标题(必须填写):<br><input name="title" type="text" size="4">
<br>正文(必须填写):<br><textarea name="nr"></textarea>
<input type="submit" name="submit" value="确认提交"></form>
<div class=main><a href=zone.php><font color=#ffffff><<返回列表</font></a></div><? include("foot.php");?>