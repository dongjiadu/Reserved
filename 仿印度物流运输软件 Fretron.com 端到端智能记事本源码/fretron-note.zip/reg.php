<html><meta http-equiv="content-type" content="text/html; charset=utf-8">
<title>爱笔记－注册</title><?php
if($_POST['submit'])
{
$name=$_POST['name'];
$pw=$_POST['pw'];
$db=sqlite_open("db/user.db");
$sql="select * from user where name='$name'";
$query=sqlite_query($db,$sql);
$res=sqlite_fetch_array($query); 
if($name=="" OR $pw==""){echo "输入项不能为空！";exit();}
if($res['name']==$name){echo "用户名已被注册！";exit();}
$sql="insert into user (name,password) values ('$name','$pw')";
$result=sqlite_query($db,$sql);
$sn=md5($name);
$db=sqlite_open("note/{$sn}.db");
$sql="create table note (id INTEGER PRIMARY KEY,title text,nr text,time datetime);";
$rw=sqlite_query($db,$sql);
if($result && $rw){
echo "<a href=login.php>注册成功！点此直接登陆。</a>";
exit();}else{echo "数据库错误！";exit();}
}?><form method="post" action="reg.php">
<br>登陆名:<input name="name" type="text" size="4">
<br>密码:<input name="pw" type="text" size="4"><input type="submit" name="submit" value="注册"></form>
</body>
</html>