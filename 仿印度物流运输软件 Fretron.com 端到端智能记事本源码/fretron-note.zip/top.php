<html><meta http-equiv="content-type" content="text/html; charset=utf-8">
<head><style type="text/css">
.main {background-color: #09f;color: #fFF}
.tl {background-color: #9ef;color: #111}
A:link{color: #02f}body {background-color: #dfd;color: #500}</style></head><? $head="<div class='main'>爱上云笔记随时随地，记录一切</div>";?>