<? include("top.php");?><?
session_start();
if(isset($_SESSION['name'])){
$name=$_SESSION['name'];
}else{session_unregister("uid");exit("错误！用户不存在。<a href=login.php>点此重新登陆</a>");}
$sn=md5($name);
$id=$_GET['id'];
$db=sqlite_open("note/{$sn}.db");
$sql="select * from note where id='$id'";
if(!sqlite_query($db,$sql)){echo "数据库错误";}
$query=sqlite_query($db,$sql);
$res=sqlite_fetch_array($query);
$title=$res['title'];
$nr=$res['nr'];
$time=$res['time'];
$id=$res['id'];
?>
<html><title>爱笔记－<? echo $title;?></title><? echo "{$head}<div class=tl>标题:{$title}</div><hr>";?><font size=6>
<? echo $nr;?></font><hr><font color=#999999>最后更新时间:
<? echo $time;echo "</font><br/>管理:<a href=edit.php?id={$id}>编辑</a>.<a href=del.php?id={$id}>删除</a>";?><div class=main><a href=zone.php><font color=#FFFFFF><<返回列表</font></a></div>
<? include("foot.php");?>