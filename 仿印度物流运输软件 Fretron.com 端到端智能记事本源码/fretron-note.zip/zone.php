<? include("top.php");?>
<?
session_start();
if(isset($_SESSION['uid'])){
$uid=$_SESSION['uid'];
$db=sqlite_open("db/user.db");
$sql="select * from user where id='$uid'";
$query=sqlite_query($db,$sql);$res=sqlite_fetch_array($query);
if($res['name']==""){session_unregister("uid");exit("用户不存在！<a href=login.php>点此重新登陆</a>");}
echo $head.'<div class=tl><form method="post" action="search.php">
<input name="word" type="text" size="4">
<input type="submit" name="submit" value="搜索"></form></div><div class=main><a href=new.php><font color=#FFFFFF>╋新建笔记</font></a></div><hr>';
$sn=md5($res['name']);
$pagesize=15;
$p = $_GET['p']?$_GET['p']:1;
$offset = ($p-1)*$pagesize;
$db=sqlite_open("note/{$sn}.db");
$sql = "SELECT * FROM note ORDER BY id DESC LIMIT  $offset , $pagesize";
$query=sqlite_query($db,$sql);
while($res=sqlite_fetch_array($query)){
$id=$res['id'];
$title=$res['title'];
$time=$res['time'];echo "<a href=view.php?id={$id}>{$title}</a><font color=#999999>{$time}</font><hr>";}
$sql="select count(*) from note";
$query=sqlite_query($db,$sql);
$res=sqlite_fetch_array($query);
$c=$res['0'];
$pagenum=ceil($c/$pagesize);
$s=$p-1;$x=$p+1;
echo "{$p}页/{$pagenum}页-{$c}条[<a href=?p={$s}><<</a>|<a href=?p={$x}>>></a>]";echo "<div class=main><a href=new.php><font color=#FFFFFF>╋ 新建笔记</font></a></div><div class=tl><a href=out.php>安全退出</a>|<a href=my.php>我的信息</a></div>";}
else{header("location: login.php");}
?><? include("foot.php");?>