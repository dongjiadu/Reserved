var fodTime = 0;
function geto(o){ return (typeof o == "object")?o:document.getElementById(o);}
function swTabs(e){if(typeof e=="string"){e=geto(e);}var isAjax,sobject;var cls="on";var tmp=e.id.split("_");var sid=tmp[0];var snum=tmp[1];sobject=geto(sid+"_"+snum+"_Info");e.className=cls;if(!isAjax){swLabs(sobject,sid,snum)}tmp=sobject=isAjax=maxItemNum=null;}
function swLabs(sobject,sid,snum){var maxItemNum;var cls="";try{var i=1;maxItemNum=gp[sid][0];while(i<=maxItemNum){if(i!=snum){var tmp1,tmp2;tmp1=geto(sid+"_"+i);tmp2=geto(sid+"_"+i+"_Info");tmp1.className=cls;tmp2.style.display = "none";}i++}}catch(e){}sobject.style.display="block";}
function tagOver(a){clearTimeout(fodTime);fodTime=0;fodTime = setTimeout(function(){swTabs(a)},50);}
function tagOut(a){clearTimeout(fodTime);fodTime=0;}

//设为首页&加入收藏
var isIE=(document.all&&document.getElementById&&!window.opera)?true:false; 
var isMozilla=(!document.all&&document.getElementById&&!window.opera)?true:false; 
var isOpera=(window.opera)?true:false;
var seturl='url(#default#homepage)';
var weburl=window.location.href;
var webname=document.title;

function myhomepage()	{
	if(isMozilla){
		try {netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");} 
		catch (e){alert("此操作被浏览器拒绝！\n请在浏览器地址栏输入“about:config”并回车\n然后将[signed.applets.codebase_principal_support]设置为'true'");}
		var prefs = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefBranch);
		prefs.setCharPref('browser.startup.homepage',weburl);
	}
	if(isIE){
		this.homepage.style.behavior=seturl;this.homepage.sethomepage(weburl); 
	}
}

function addfavorite()
{

	if(isMozilla){
		if (document.all){ window.external.addFavorite(weburl,webname);}
		else if (window.sidebar){ window.sidebar.addPanel(webname, weburl,"");}
	}
	if(isIE){window.external.AddFavorite(weburl, webname);}	
}

function SetSearchValue(s)
{
if(s.value=='请输入要查询的项目')
s.value=''
}