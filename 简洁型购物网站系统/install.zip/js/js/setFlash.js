
function flash_write(strSrc, strW, strH )
{
	document.write('<Object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" WIDTH="'+strW+'" HEIGHT="'+strH+'" id="company_flash_sub_v1" ALIGN="">');
	document.write('<PARAM NAME=movie VALUE="'+strSrc+'"> ');
	document.write('<PARAM NAME=menu VALUE=false> ');
	document.write('<PARAM NAME=quality VALUE=high> ');
	document.write('<PARAM NAME=wmode VALUE=transparent> ');
	document.write('<PARAM NAME=bgcolor VALUE=#CCCCCC> ');
	document.write('<EMBED src="'+strSrc+'" menu=false quality=high wmode=transparent bgcolor=#CCCCCC  WIDTH="'+strW+'" HEIGHT="'+strH+'" NAME="company_flash_sub_v1" ALIGN="" TYPE="application/x-shockwave-flash" PLUGINSPAGE="http://www.macromedia.com/go/getflashplayer"></EMBED>');
	document.write('</OBJECT>');
}


