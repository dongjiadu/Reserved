function showLay(num,Id){
 var temp="";
 for(var i=1;i<=num;i++)
 {
	 
	 if (Id != i )
	 {
	   temp = "showpro"+i;
	   temp1 = "showmenu"+i;
	   document.getElementById(temp).style.display="none"; 
	   document.getElementById(temp1).className="hot12"; 
 
	 }
 }

 divId = "showpro"+Id;
 divId1 = "showmenu"+Id;
  objDiv = document.getElementById(divId).style.display="";
  document.getElementById(divId1).className="hot"; 

}