function taggle(a) {
	for (var i=1; i<=4; i++) {
		document.getElementById("detail"+i).style.backgroundColor = "#fff";
		document.getElementById("detail"+i).style.color = "#333";
		document.getElementById("content"+i).style.display = "none";
	}
	document.getElementById("detail"+a).style.backgroundColor = "green";
	document.getElementById("detail"+a).style.color = "#fff";
	document.getElementById("content"+a).style.display = "block";
}